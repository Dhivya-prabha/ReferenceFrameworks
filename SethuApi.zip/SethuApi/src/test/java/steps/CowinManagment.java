package steps;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.containsInAnyOrder;
import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.equalTo;

import java.io.File;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.lang3.StringUtils;

import com.github.javafaker.Faker;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;

public class CowinManagment extends Common{

    
	@Given("set up the log")
	public void setUp(){ 
		request = RestAssured.given().log().all();
	}
		
	@Given("set up the content type")
	public void setUpContentType(){ 
		request = request.contentType(ContentType.JSON).accept(ContentType.JSON);
	}
	
	@When("get all districts")
	public void placethegetRequestForDistricts(){ 
       response =request.get("admin/location/districts/31");
       response.prettyPrint();
       JsonPath jsonPath=response.jsonPath();
       districtId=jsonPath.getString("districts.district_id");
      
	}
	
	@And ("get all states")
	public void placeTheGetRequest(){ 
       response =request.get("admin/location/states");
       response.prettyPrint();


	}
	
	@Then ("the status code should be {int}")
	public void verfyStatusCode(int statusCode){ 
       response.then().assertThat().statusCode(statusCode);
	}       
       
      
}


