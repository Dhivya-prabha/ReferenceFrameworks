package services;

import static org.hamcrest.Matchers.containsString;
import io.restassured.http.ContentType;
import org.testng.annotations.Test;

public class PostRequest extends BaseClass {
	@Test
	public void postRequest() {

		response = request.given().contentType(ContentType.JSON)
				.body("{\r\n" + "  \"mobile\": \"9677138970\"\r\n" + "}").post("auth/generateOTP");

		System.out.println(response.statusCode());
//		Step 5: print Response
		response.prettyPrint();

	}
}