package services;

import static org.hamcrest.Matchers.containsString;

import java.io.File;
import java.util.List;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class GetAllState extends BaseClass {

	@Test
	public void getAllState() {

		response = request
				.when()
				.header("Accept-Language", "en_IN")
				.get("admin/location/states");
		response.then()
		.assertThat()
		.statusCode(200)
		.body(containsString("Tamil Nadu"))
		.extract().response()
		.prettyPrint();

	}

}
