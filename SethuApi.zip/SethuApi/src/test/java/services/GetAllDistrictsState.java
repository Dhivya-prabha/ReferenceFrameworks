package services;

import static org.hamcrest.Matchers.containsString;

import java.io.File;
import java.util.List;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class GetAllDistrictsState extends BaseClass {

	@Test
	public void getAllDistrictsState() {

		response = request
				.when()
				.get("admin/location/districts/31");
		response.then()
		.assertThat()
		.statusCode(200)
		.body(containsString("Chennai"))
		.extract().response()
		.prettyPrint();

	}

}
