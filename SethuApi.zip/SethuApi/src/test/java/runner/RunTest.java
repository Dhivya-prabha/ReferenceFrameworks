package runner;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;
import io.cucumber.testng.CucumberOptions.SnippetType;

@CucumberOptions(features = "src/test/java/features",
				 glue = {"steps","hooks"},
				 monochrome = true,dryRun=false,
				 //snippets=SnippetType.CAMELCASE,
				 plugin= {"html:reprot"}
			  // tags={"@smoke", "~@regression"},
               // tags={"@smoke","@regression"}

       )

public class RunTest extends AbstractTestNGCucumberTests{

}

