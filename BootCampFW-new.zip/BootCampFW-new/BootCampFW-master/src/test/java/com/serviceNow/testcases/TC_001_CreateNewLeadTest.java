package com.serviceNow.testcases;

import org.testng.annotations.Test;

public class TC_001_CreateNewLeadTest {

  @Test
  public void createNewLeadTest() {
    throw new RuntimeException("Test not implemented");
  }
}
